# Combined Script: Card Recognition(HW9) and Blackjack Game Assistant(HW8)
# Copyright 2024 ZonghaiJIng zonghai@bu.edu


                                                    #!!!!!!!!!!!read me please!!!!!!!!!!!!
#the code should run in the cv environment, and the blackjack game sample is from Blackjack Master 3 which can be downloaded in 
#the Microsoft Store(choose the 2 deck table)


#AI reference: most of recognition part are generate from CHATGPT(I just modify the parameter), and then let AI use the output
#of recognition to serve as input of HW8(to take place of the manually input by keyboard)


#Summary: I tried 3 ways to the correct recognition. Firstly, I tried ORB (Oriented FAST and Rotated BRIEF) to match the detected 
#image and the sample, doesn't work. Then, I download tesseract module, however, when I did that, the cv2 could not be found in
#the opencv environment. I tried uninstall then download, nothing change. SO I have to remove the whole environment and install
#the cv envs again. Finally, I used the detected image to serve as the sample, and finally they match up.
#What's more, since most of time we can judge what to do by ourself after hit(except 2,2 and get 2 after hit), I did't set up cv on third
#card of player but change to input manually to deal with these small probability events.


#Problem: Since I used the Blackjack3 from the Microsoft Store and noted down the location
#on my own laptop, please download the same app and show this app in full screen(success
#sample is shown in the Readme2.png). Otherwise, the code may not able to recognize the 
#card correctly.
                                                    #!!!!!!!!!!!read me please!!!!!!!!!!!!

import pyautogui
import cv2
import numpy as np
import os
import random
from collections import Counter

# --- Card Recognition Section ---

# Step 1: Capture the screenshot
screenshot = pyautogui.screenshot()
screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)

# Step 2: Crop the card images using the provided coordinates

# Dealer's card coordinates
dealer_x1, dealer_y1, dealer_x2, dealer_y2 = 910 + 3, 289 + 3, 946, 327 - 5

# Player's card 1 coordinates
player1_x1, player1_y1, player1_x2, player1_y2 = 906, 637, 941, 673 - 4

# Player's card 2 coordinates
player2_x1, player2_y1, player2_x2, player2_y2 = 941, 652, 970, 688 - 4

# Crop the card images
dealer_card_img = screenshot[dealer_y1:dealer_y2, dealer_x1:dealer_x2]
player_card1_img = screenshot[player1_y1:player1_y2, player1_x1:player1_x2]
player_card2_img = screenshot[player2_y1:player2_y2, player2_x1:player2_x2]

# Optional: Save the cropped images for verification
cv2.imwrite('dealer_card.png', dealer_card_img)
cv2.imwrite('player_card1.png', player_card1_img)
cv2.imwrite('player_card2.png', player_card2_img)

# Step 3: Load the card templates
templates_path = 'card_templates'
card_templates = {}

for filename in os.listdir(templates_path):
    if filename.endswith('.png'):
        card_value = filename.split('_')[0]  # Extract the card point
        template_image = cv2.imread(os.path.join(templates_path, filename), 0)  # Load in grayscale
        if card_value in card_templates:
            card_templates[card_value].append(template_image)
        else:
            card_templates[card_value] = [template_image]

# Step 4: Define the template matching function
def match_card(card_image, templates, threshold=0.5):
    # Preprocess card image
    card_gray = cv2.cvtColor(card_image, cv2.COLOR_BGR2GRAY)
    card_gray = cv2.GaussianBlur(card_gray, (5, 5), 0)
    card_gray = cv2.equalizeHist(card_gray)

    best_match = None
    max_val = -1
    for card_value, template_list in templates.items():
        for template in template_list:
            # Preprocess template
            template_processed = cv2.GaussianBlur(template, (5, 5), 0)
            template_processed = cv2.equalizeHist(template_processed)

            # Ensure the template and card image are the same size
            if template_processed.shape != card_gray.shape:
                template_processed = cv2.resize(template_processed, (card_gray.shape[1], card_gray.shape[0]))

            # Match template
            res = cv2.matchTemplate(card_gray, template_processed, cv2.TM_CCOEFF_NORMED)
            min_val, max_val_local, min_loc, max_loc = cv2.minMaxLoc(res)
            print(f"Matching score for {card_value}: {max_val_local:.2f}")
            if max_val_local > max_val:
                max_val = max_val_local
                best_match = card_value
    return best_match

# Step 5: Identify the cards
identified_cards = []

for card_image in [dealer_card_img, player_card1_img, player_card2_img]:
    card_point = match_card(card_image, card_templates)
    identified_cards.append(card_point)

print("Identified Cards:", identified_cards)

# --- Blackjack Game Assistant Section ---

# Function to create the deck
def create_deck():
    single_deck = [str(value) for value in range(2, 11)] + ['J', 'Q', 'K', 'A']
    deck = single_deck * 4  # 4 suits in 1 deck
    deck *= 4  # 4 decks
    return deck

# Function to get card value
def get_card_value(card):
    if card.upper() in ['J', 'Q', 'K']:
        return 10
    elif card.upper() == 'A':
        return 11  # Ace initially counted as 11
    else:
        try:
            value = int(card)
            if 2 <= value <= 10:
                return value
            else:
                print(f"Invalid card value: {card}")
                return None
        except ValueError:
            print(f"Invalid card input: {card}")
            return None

# Function to calculate hand value
def cal_hand_value(cards):
    total = 0
    aces = 0
    for card in cards:
        value = get_card_value(card)
        if value is not None:
            total += value
            if card.upper() == 'A':
                aces += 1
        else:
            return None
    while total > 21 and aces:
        total -= 10  # Count Ace as 1 instead of 11 to prevent bust
        aces -= 1
    return total

# Dealer's play
def dealer_play(dealer_hand, deck):
    dealer_total = cal_hand_value(dealer_hand)
    if dealer_total is None:
        return None
    while dealer_total < 17:
        if not deck:
            break
        card = deck.pop()
        dealer_hand.append(card)
        dealer_total = cal_hand_value(dealer_hand)
        if dealer_total is None:
            return None
    return dealer_total

# Simulate outcome
def simulate_outcome(player_hand, dealer_upcard, deck, act):
    deck = deck.copy()
    random.shuffle(deck)
    known_cards = player_hand + [dealer_upcard]

    # Remove known cards from deck
    for card in known_cards:
        if card in deck:
            deck.remove(card)

    if act == 'Stand':
        # Player does not draw
        player_total = cal_hand_value(player_hand)
        dealer_hand = [dealer_upcard]
        if deck:
            dealer_hole = deck.pop()
            dealer_hand.append(dealer_hole)
        else:
            return 'Tie'  # No more cards
        dealer_total = dealer_play(dealer_hand, deck)
    elif act == 'Hit':
        # Player hits once
        if deck:
            player_card = deck.pop()
            player_hand.append(player_card)
            player_total = cal_hand_value(player_hand)
            if player_total > 21:
                return 'Lose'  # Player busts immediately
        else:
            return 'Tie'
        dealer_hand = [dealer_upcard]
        if deck:
            dealer_hole = deck.pop()
            dealer_hand.append(dealer_hole)
        else:
            return 'Tie'
        dealer_total = dealer_play(dealer_hand, deck)
    else:
        return None

    if dealer_total is None:
        return None

    if dealer_total > 21:
        return 'Win'  # Dealer busts
    if player_total > 21:
        return 'Lose'  # Player busts
    if player_total > dealer_total:
        return 'Win'
    elif player_total < dealer_total:
        return 'Lose'
    else:
        return 'Tie'

# Calculate probabilities
def calculate_probabilities(player_hand, dealer_upcard, deck, simulations=10000):
    outcomes = {'Stand': Counter(), 'Hit': Counter()}
    deck_for_sim = deck.copy()

    for act in ['Stand', 'Hit']:
        for _ in range(simulations):
            if act == 'Stand':
                result = simulate_outcome(player_hand.copy(), dealer_upcard, deck_for_sim, act)
            elif act == 'Hit':
                result = simulate_outcome(player_hand.copy(), dealer_upcard, deck_for_sim, act)
            if result:
                outcomes[act][result] += 1

    prob = {}
    for act in outcomes:
        total = sum(outcomes[act].values())
        if total > 0:
            prob[act] = {
                'Win': outcomes[act]['Win'] / total,
                'Lose': outcomes[act]['Lose'] / total,
                'Tie': outcomes[act]['Tie'] / total
            }
        else:
            prob[act] = {'Win': 0, 'Lose': 0, 'Tie': 0}

    return prob

# Function to validate card input
def validate_card(card, deck):
    valid_cards = [str(n) for n in range(2, 11)] + ['J', 'Q', 'K', 'A']
    if card.upper() not in valid_cards:
        print(f"Invalid card '{card}'. Please enter a valid card (2-10, J, Q, K, A).")
        return False
    if card.upper() not in deck:
        print(f"Card '{card.upper()}' is not available in the deck.")
        return False
    return True

# Main function
def main():
    print("Welcome to the Blackjack Game Assistant with Probability Calculation!")

    # Use the identified cards from the card recognition section
    identified_cards_upper = [card.upper() if card else 'Unknown' for card in identified_cards]
    dealer_card = identified_cards_upper[0]
    player_cards = identified_cards_upper[1:]

    # Check for unknown cards
    if 'Unknown' in identified_cards_upper:
        print("Could not identify all cards. Please check the card recognition process.")
        print(f"Identified Cards: {identified_cards_upper}")
        return

    print(f"\nYour initial cards: {player_cards}")
    print(f"Dealer's upcard: {dealer_card}")

    player_total = cal_hand_value(player_cards)
    if player_total is None:
        print("Invalid player cards detected. Please try again.")
        return
    print(f"Your hand total is: {player_total}")

    if get_card_value(dealer_card) is None:
        print("Invalid dealer upcard detected. Please try again.")
        return

    # Create and prepare the deck
    deck = create_deck()

    # Remove known cards from the deck
    for card in player_cards + [dealer_card]:
        if card in deck:
            deck.remove(card)

    while True:
        print("\nCalculating probabilities based on current hand...")
        prob = calculate_probabilities(player_cards, dealer_card, deck)
        for act in prob:
            print(f"\nAction: {act}")
            print(f"Probability of Winning: {prob[act]['Win']*100:.2f}%")
            print(f"Probability of Losing: {prob[act]['Lose']*100:.2f}%")
            print(f"Probability of Tying: {prob[act]['Tie']*100:.2f}%")

        # Decide whether to Hit or Stand
        while True:
            decision = input("\nDo you want to Hit or Stand? (h/s): ").strip().lower()
            if decision in ['h', 's']:
                break
            else:
                print("Invalid input. Please enter 'h' to Hit or 's' to Stand.")

        if decision == 's':
            print("\nYou chose to Stand.")
            break
        elif decision == 'h':
            # Prompt user to enter the new card
            while True:
                new_card = input("Enter the new card you have drawn (e.g., 'A', '7', 'K'): ").strip().upper()
                if validate_card(new_card, deck):
                    break
                else:
                    print("Please enter a valid and available card.")

            # Add the new card to player's hand and remove it from the deck
            player_cards.append(new_card)
            deck.remove(new_card)
            player_total = cal_hand_value(player_cards)
            print(f"\nYour new hand: {player_cards}")
            print(f"Your new hand total is: {player_total}")
            print(f"Dealer's upcard: {dealer_card}")  # reprint the dealer's card

            if player_total > 21:
                print("You have busted! Game Over.")
                return
            elif player_total == 21:
                print("You have 21!")
                break
            else:
                print("You can choose to Hit or Stand again.")

    # Final probability calculation before finalizing the game
    print("\nFinal probability calculations based on your decision to Stand:")
    prob = calculate_probabilities(player_cards, dealer_card, deck)
    for act in prob:
        print(f"\nAction: {act}")
        print(f"Probability of Winning: {prob[act]['Win']*100:.2f}%")
        print(f"Probability of Losing: {prob[act]['Lose']*100:.2f}%")
        print(f"Probability of Tying: {prob[act]['Tie']*100:.2f}%")

    print("\nThank you for using the Blackjack Game Assistant. Good luck!")

if __name__ == "__main__":
    main()
