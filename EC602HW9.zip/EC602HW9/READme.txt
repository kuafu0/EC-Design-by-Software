                                                #!!!!!!!!!!!read me please!!!!!!!!!!!!
#the code should run in the cv environment, and the blackjack game sample is from Blackjack Master 3 which can be downloaded in 
#the Microsoft Store(choose the  2 deck table)


#AI reference: most of recognition part are generate from CHATGPT(I just modify the parameter), and then let AI use the output
#of recognition to serve as input of HW8(to take place of the manually input by keyboard)


#Summary: I tried 3 ways to the correct recognition. Firstly, I tried ORB (Oriented FAST and Rotated BRIEF) to match the detected 
#image and the sample, doesn't work. Then, I download tesseract module, however, when I did that, the cv2 could not be found in
#the opencv environment. I tried uninstall then download, nothing change. SO I have to remove the whole environment and install
#the cv envs again. Finally, I used the detected image to serve as the sample, and finally they match up.
#What's more, since most of time we can judge what to do by ourself after hit(except 2,2 and get 2 after hit), I did't set up cv on third
#card of player but change to input manually to deal with these small probability events.


#Problem: Since I used the Blackjack3 from the Microsoft Store and noted down the location
#on my own laptop, please download the same app and show this app in full screen(success
#sample is shown in the Readme2.png). Otherwise, the code may not able to recognize the 
#card correctly.
                                                #!!!!!!!!!!!read me please!!!!!!!!!!!!